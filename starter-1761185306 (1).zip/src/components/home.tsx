function Home() {
  return (
    <div className="w-screen h-screen">
    </div>
  )
}

export default Home
